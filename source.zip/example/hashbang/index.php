<?php
$useHtml5Mode = false;

include("../common.php");
?>